import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, ImageBackground } from 'react-native';

export default function App() {
  return (
      <ImageBackground
      source={{uri:'https://wallpapercave.com/wp/wp6878176.jpg'}}
      resizeMode='stretch'
      style={styles.container}
      >
       <Image
       style={styles.img}
       source={{uri:'https://www.kindpng.com/picc/m/343-3438299_nissan-gtr-r34-jdm-nissan-skyline-gtr-r34.png'}}
        
      />
      <Text
      style={styles.estilotexto}>GTR ESTOURADO KPKP</Text>

      <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
        <ImageBackground
       source={{uri:'https://avatars.githubusercontent.com/u/18017848?v=4'}}

      style={styles.Cardveiculo}>
     
      <Text style={styles.estilotexto}>ELITON CAMARGO</Text>
      <Text style={styles.estilotexto2}>APENAS🤠👍</Text>
        </ImageBackground>
      </ImageBackground>
      
 
  );
}


const styles = StyleSheet.create({
  img:{
    width: 280,
    height: 120
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  estilotexto:{
  color: '#836FFF',
  fontWeight: "bold",
  marginTop: 20,
  fontSize: 24,
  paddingLeft: 10,
  },
  estilotexto2:{
    color: '#836FFF',
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 200,
    fontSize: 24,
    borderRadius: 10,
    borderWidth: 1,
    paddingLeft: 10,
    },
  Cardveiculo: {
  width: 380,
  height: 250,
  backgroundColor: '#483D8B'
  },
});
